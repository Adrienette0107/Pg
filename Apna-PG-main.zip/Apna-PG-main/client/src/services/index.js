import apiClient from './api';

// Auth Services
export const authService = {
  register: (userData) => apiClient.post('/auth/register', userData),
  login: (email, password) => apiClient.post('/auth/login', { email, password }),
  getCurrentUser: () => apiClient.get('/auth/me'),
  updateProfile: (profileData) => apiClient.put('/auth/profile', profileData),
  logout: () => apiClient.post('/auth/logout'),
};

// PG Services
export const pgService = {
  getAllPGs: (params) => apiClient.get('/pgs', { params }),
  getPGById: (id) => apiClient.get(`/pgs/${id}`),
  createPG: (pgData) => apiClient.post('/pgs', pgData),
  updatePG: (id, pgData) => apiClient.put(`/pgs/${id}`, pgData),
  deletePG: (id) => apiClient.delete(`/pgs/${id}`),
  getPGRooms: (pgId) => apiClient.get(`/pgs/${pgId}/rooms`),
};

// Room Services
export const roomService = {
  getRoomById: (id) => apiClient.get(`/rooms/${id}`),
  createRoom: (roomData) => apiClient.post('/rooms', roomData),
  updateRoom: (id, roomData) => apiClient.put(`/rooms/${id}`, roomData),
  deleteRoom: (id) => apiClient.delete(`/rooms/${id}`),
  updateAvailability: (id, availability) => 
    apiClient.put(`/rooms/${id}/availability`, availability),
};

// Booking Services
export const bookingService = {
  createBooking: (bookingData) => apiClient.post('/bookings', bookingData),
  getBookingById: (id) => apiClient.get(`/bookings/${id}`),
  getUserBookings: (params) => apiClient.get('/bookings/user/bookings', { params }),
  getOwnerBookings: (params) => apiClient.get('/bookings/owner/bookings', { params }),
  approveBooking: (id) => apiClient.put(`/bookings/${id}/approve`),
  rejectBooking: (id, data) => apiClient.put(`/bookings/${id}/reject`, data),
  cancelBooking: (id, data) => apiClient.put(`/bookings/${id}/cancel`, data),
};

// Review Services
export const reviewService = {
  createReview: (reviewData) => apiClient.post('/reviews', reviewData),
  getPGReviews: (pgId, params) => apiClient.get(`/reviews/pg/${pgId}`, { params }),
  getReviewById: (id) => apiClient.get(`/reviews/${id}`),
  updateReview: (id, reviewData) => apiClient.put(`/reviews/${id}`, reviewData),
  deleteReview: (id) => apiClient.delete(`/reviews/${id}`),
  markHelpful: (id) => apiClient.post(`/reviews/${id}/helpful`),
  respondToReview: (id, response) => apiClient.put(`/reviews/${id}/respond`, response),
};

// Admin Services
export const adminService = {
  getPlatformStats: () => apiClient.get('/admin/stats'),
  getPendingPGs: (params) => apiClient.get('/admin/pgs/pending', { params }),
  verifyPG: (id) => apiClient.put(`/admin/pgs/${id}/verify`),
  blockPG: (id, data) => apiClient.put(`/admin/pgs/${id}/block`, data),
  unblockPG: (id) => apiClient.put(`/admin/pgs/${id}/unblock`),
  getPendingReviews: (params) => apiClient.get('/admin/reviews/pending', { params }),
  approveReview: (id) => apiClient.put(`/admin/reviews/${id}/approve`),
  rejectReview: (id) => apiClient.put(`/admin/reviews/${id}/reject`),
  getAllUsers: (params) => apiClient.get('/admin/users', { params }),
  deactivateUser: (id) => apiClient.put(`/admin/users/${id}/deactivate`),
};
