const PG = require('../models/PG');
const Room = require('../models/Room');
const Booking = require('../models/Booking');
const User = require('../models/User');

// @route   POST /api/pgs
// @desc    Create a new PG (Owner only)
// @access  Private
exports.createPG = async (req, res) => {
  try {
    const {
      name,
      description,
      address,
      location,
      nearbyCollege,
      nearbySchool,
      nearbyOffice,
      genderAllowed,
      amenities,
      rules,
      allowsDailyStay,
      allowsMonthlyStay,
      securityDepositPercentage,
    } = req.body;

    // Validation
    if (!name || !description || !address || !genderAllowed) {
      return res.status(400).json({
        success: false,
        message: 'Required fields: name, description, address, genderAllowed',
      });
    }

    const pgData = {
      name,
      description,
      address,
      location,
      nearbyCollege,
      nearbySchool,
      nearbyOffice,
      genderAllowed,
      amenities,
      rules,
      allowsDailyStay,
      allowsMonthlyStay,
      securityDepositPercentage,
      owner: req.user._id,
      ownerEmail: req.user.email,
      ownerPhone: req.user.phone,
    };

    const pg = await PG.create(pgData);

    res.status(201).json({
      success: true,
      message: 'PG created successfully. Awaiting admin verification.',
      pg,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error creating PG',
      error: error.message,
    });
  }
};

// @route   GET /api/pgs
// @desc    Get all verified PGs with filters
// @access  Public
exports.getPGs = async (req, res) => {
  try {
    const { city, gender, budget, nearbyCollege, page = 1, limit = 10 } = req.query;

    let filter = { isVerified: true, isActive: true, isBlocked: false };

    if (city) filter['address.city'] = city;
    if (gender) filter.genderAllowed = gender;
    if (nearbyCollege) filter.nearbyCollege = nearbyCollege;

    if (budget) {
      filter.minPrice = { $lte: parseInt(budget) };
    }

    const skip = (page - 1) * limit;

    const pgs = await PG.find(filter)
      .populate('owner', 'fullName phone email')
      .skip(skip)
      .limit(parseInt(limit))
      .sort({ createdAt: -1 });

    const total = await PG.countDocuments(filter);

    res.status(200).json({
      success: true,
      pgs,
      pagination: {
        total,
        page: parseInt(page),
        limit: parseInt(limit),
        pages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching PGs',
      error: error.message,
    });
  }
};

// @route   GET /api/pgs/:id
// @desc    Get single PG with rooms
// @access  Public
exports.getPGById = async (req, res) => {
  try {
    const pg = await PG.findById(req.params.id)
      .populate('owner', 'fullName phone email')
      .populate('rooms');

    if (!pg) {
      return res.status(404).json({
        success: false,
        message: 'PG not found',
      });
    }

    res.status(200).json({
      success: true,
      pg,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching PG',
      error: error.message,
    });
  }
};

// @route   PUT /api/pgs/:id
// @desc    Update PG (Owner only)
// @access  Private
exports.updatePG = async (req, res) => {
  try {
    let pg = await PG.findById(req.params.id);

    if (!pg) {
      return res.status(404).json({
        success: false,
        message: 'PG not found',
      });
    }

    // Check if user is owner
    if (pg.owner.toString() !== req.user._id.toString() && req.user.role !== 'Admin') {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to update this PG',
      });
    }

    pg = await PG.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });

    res.status(200).json({
      success: true,
      message: 'PG updated successfully',
      pg,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error updating PG',
      error: error.message,
    });
  }
};

// @route   DELETE /api/pgs/:id
// @desc    Delete PG (Owner only)
// @access  Private
exports.deletePG = async (req, res) => {
  try {
    const pg = await PG.findById(req.params.id);

    if (!pg) {
      return res.status(404).json({
        success: false,
        message: 'PG not found',
      });
    }

    // Check if user is owner
    if (pg.owner.toString() !== req.user._id.toString() && req.user.role !== 'Admin') {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to delete this PG',
      });
    }

    await PG.findByIdAndDelete(req.params.id);

    res.status(200).json({
      success: true,
      message: 'PG deleted successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error deleting PG',
      error: error.message,
    });
  }
};

// @route   GET /api/pgs/:id/rooms
// @desc    Get all rooms in a PG
// @access  Public
exports.getPGRooms = async (req, res) => {
  try {
    const rooms = await Room.find({ pg: req.params.id }).sort({ roomNumber: 1 });

    res.status(200).json({
      success: true,
      rooms,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching rooms',
      error: error.message,
    });
  }
};
